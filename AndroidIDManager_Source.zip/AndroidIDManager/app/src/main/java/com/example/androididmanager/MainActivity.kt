package com.example.androididmanager

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.security.SecureRandom

/**
 * Android ID Manager - safe local test-profile manager.
 *
 * IMPORTANT:
 * This app generates and stores test identifiers inside its own private
 * preferences. It does NOT change Settings.Secure.ANDROID_ID, another app's
 * SSAID, PackageManager identity, Linux UID, signing identity, or device state.
 */
class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("test_profiles", MODE_PRIVATE) }
    private val random = SecureRandom()

    private lateinit var packageInput: EditText
    private lateinit var idOutput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(0xFFF6F7FB.toInt())
        }

        val scroll = ScrollView(this)
        scroll.addView(page)

        val title = TextView(this).apply {
            text = "Android ID Manager"
            textSize = 25f
            setTextColor(0xFF172033.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "本地测试标识符管理器"
            textSize = 14f
            setTextColor(0xFF667085.toInt())
            setPadding(0, dp(5), 0, dp(20))
        }
        page.addView(subtitle, matchWrap())

        page.addView(sectionLabel("目标测试应用包名"))
        packageInput = EditText(this).apply {
            hint = "例如：com.example.mytestapp"
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        page.addView(packageInput, matchWrap())

        page.addView(sectionLabel("本地测试 ID"))
        idOutput = EditText(this).apply {
            hint = "生成后显示 16 位十六进制值"
            textSize = 16f
            typeface = Typeface.MONOSPACE
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        page.addView(idOutput, matchWrap())

        page.addView(actionButton("随机生成", 0xFF2457D6.toInt()) {
            idOutput.setText(generateTestId())
            setStatus("已生成新的本地测试 ID，尚未保存。")
        })
        page.addView(actionButton("保存此应用的测试配置", 0xFF18794E.toInt()) {
            saveProfile()
        })
        page.addView(actionButton("读取已保存配置", 0xFF475467.toInt()) {
            loadProfile()
        })
        page.addView(actionButton("删除此应用配置", 0xFFB42318.toInt()) {
            deleteProfile()
        })

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF344054.toInt())
            setPadding(0, dp(16), 0, dp(12))
            text = "等待操作。"
        }
        page.addView(status, matchWrap())

        val note = TextView(this).apply {
            text = "重要说明\n此版本仅在 Android ID Manager 自身的私有存储中生成和保存测试值。它不会修改系统 Android ID（SSAID），也不会改变其他应用实际读取到的 Android ID。若要验证测试值，请在你自己开发的测试应用中接入同一测试配置接口。"
            textSize = 13f
            setTextColor(0xFF7A2E0E.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFFFFF1E8.toInt())
        }
        page.addView(note, matchWrap())

        setContentView(scroll)
    }

    private fun generateTestId(): String {
        val bytes = ByteArray(8)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun saveProfile() {
        val pkg = packageInput.text.toString().trim()
        val id = idOutput.text.toString().trim().lowercase()

        if (!isValidPackageName(pkg)) {
            toast("请输入有效的包名，例如 com.example.app")
            return
        }
        if (!id.matches(Regex("^[0-9a-f]{16}$"))) {
            toast("测试 ID 必须是 16 位十六进制字符")
            return
        }

        prefs.edit().putString("profile:$pkg", id).apply()
        setStatus("已保存 $pkg 的本地测试配置。")
    }

    private fun loadProfile() {
        val pkg = packageInput.text.toString().trim()
        if (!isValidPackageName(pkg)) {
            toast("请先输入有效包名")
            return
        }
        val id = prefs.getString("profile:$pkg", null)
        if (id == null) {
            setStatus("没有找到该包名对应的本地配置。")
        } else {
            idOutput.setText(id)
            setStatus("已读取 $pkg 的本地测试配置。")
        }
    }

    private fun deleteProfile() {
        val pkg = packageInput.text.toString().trim()
        if (!isValidPackageName(pkg)) {
            toast("请先输入有效包名")
            return
        }
        prefs.edit().remove("profile:$pkg").apply()
        idOutput.setText("")
        setStatus("已删除 $pkg 的本地测试配置。")
    }

    private fun isValidPackageName(value: String): Boolean {
        if (value.length !in 3..255) return false
        return value.split('.').size >= 2 &&
            value.split('.').all { part ->
                part.isNotEmpty() &&
                    part[0].isLetter() &&
                    part.all { it.isLetterOrDigit() || it == '_' }
            }
    }

    private fun sectionLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF344054.toInt())
        setPadding(0, dp(16), 0, dp(7))
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(color)
            setOnClickListener { action() }
            val lp = matchWrap().apply { topMargin = dp(9) }
            layoutParams = lp
        }

    private fun setStatus(message: String) {
        status.text = message
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
