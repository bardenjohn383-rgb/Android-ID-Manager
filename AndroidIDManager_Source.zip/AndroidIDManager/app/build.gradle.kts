plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.androididmanager"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.example.androididmanager"
        minSdk = 23
        targetSdk = 37
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
