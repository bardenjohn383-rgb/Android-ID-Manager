# Android ID Manager

Kotlin 原生 Android 项目，浅色界面，面向本地测试标识符配置管理。

## 当前版本实现

- 为输入的测试应用包名生成独立的随机 16 位十六进制测试 ID
- 使用应用私有 SharedPreferences 保存、读取和删除配置
- 校验包名格式和测试 ID 格式
- 不需要 Root 权限
- 不枚举全部已安装应用，不申请 QUERY_ALL_PACKAGES
- 不修改 Android 系统 Android ID（SSAID）
- 不修改其他应用的身份、UID、签名、PackageManager 数据或系统设置

## SDK 配置

- compileSdk: 37
- targetSdk: 37
- minSdk: 23
- Java/Kotlin JVM target: 17

构建需要安装 Android SDK Platform 37、JDK 17、Android Gradle Plugin 9.0.0 对应的 Gradle 环境。

## 构建 APK

在 Android Studio 中打开项目根目录，等待 Gradle Sync 完成，然后选择：

Build > Build Bundle(s) / APK(s) > Build APK(s)

生成的 APK 通常位于：

`app/build/outputs/apk/debug/app-debug.apk`

## 重要：Android ID 的边界

Android 的 `Settings.Secure.ANDROID_ID` 是系统提供的 SSAID，受 Android 版本、用户、应用签名等规则约束。本项目保存的是本应用私有空间内的测试值，不会让第三方应用读取到该值。

如果你维护自己的测试应用，可以在测试应用中显式接入一个测试 ID provider，并仅在 debug/test 构建中启用。不要将本地测试 ID 当作系统 SSAID。
